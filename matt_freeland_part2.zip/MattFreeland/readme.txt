Thank you for using this program.
Running this program uses Node.Js

The file artandlogic2.javascript should be run from the command line.

The program has an optional boolean argument.
   True will append the output to the existing output file.
  False will overwrite any existing data in the output file. This is the default.

The input file:
The input file reads information as a single string. It will automatically separate out commands from input values.

The ability to encode data has been removed as it is not necessary for this program.
