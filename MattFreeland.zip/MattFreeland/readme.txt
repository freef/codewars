Thank you for using this program.
Running this program uses Node.Js

The file artandlogic.javascript should be run from the command line.

The program accepts two arguments:
1) 'enc' or 'dec' - declare if you want to encode integers or decode hexidecimal integers
2) a boolean - true will append the output to the existing output file, false will overwrite it. This is the default

The input file:
The input file reads information separated with a space. It is recommended to remove trailing spaces.
If an input is invalid it will be rendered in the output file as ERROR. 
